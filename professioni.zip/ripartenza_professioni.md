# Ripartenza — Vademecum dell'italiano per le professioni

Aggiornato al 30 ottobre 2026. Da leggere all'inizio di ogni nuova conversazione su questo vademecum, insieme alle istruzioni del progetto «Vademecum italiano» (versione 1.1), che valgono anche qui salvo le differenze indicate sotto.

## 1. Che cos'è

È il secondo vademecum di Fabio: stesso stile e stesso codice del vademecum di grammatica, ma per l'italiano delle professioni. Erano previsti cinque settori, **14 schede ciascuno** (deciso da Fabio il 25 ottobre 2026; il numero lo decidono gli argomenti: se una scheda si rivela debole o ripete un'altra, si toglie e il settore resta a 13):

- **Medicina** — per i medici (non per infermieri o altre professioni sanitarie) — **fatto**
- **Diritto** — giuristi e contratti — **fatto** (28 ottobre 2026)
- **Banca** — banche e finanza — **fatto** (28 ottobre 2026; solo temi strettamente bancari, al massimo di economia)
- **Software** — sviluppatori — **non si fa** (deciso da Fabio il 28 ottobre 2026: i termini del settore sono quasi tutti inglesi). Dal 28 ottobre 2026 (app.js 1.7) Software è tolto anche dal codice e `software.json` non esiste più.
- **Vendite** — commerciali e venditori — **fatto** (28 ottobre 2026)

Con Diritto i settori sono **chiusi** (28 ottobre 2026): quattro settori, 56 schede. Il 30 ottobre 2026 Fabio ha chiesto una sezione in più, **Colloqui** («Per tutti i settori»), con una sola scheda: *Il colloquio di lavoro* (vedi §8). Totale: 57 schede.

Le schede non sono strutture grammaticali ma argomenti e situazioni di lavoro del settore. **La grammatica non ci va** (c'è il corso per questo): niente spiegazioni di regole; le frasi pronte restano e si imparano intere. Unica eccezione ammessa: una nota di registro di una riga (per esempio quando dare del Lei).

Pubblico: studenti **internazionali** dal livello **A2 al C1**. I testi delle spiegazioni sono in italiano semplice; la progressione per livello sta negli esercizi (vedi §5).

Pubblicazione: repository `fdelse/fdelse.github.io`, cartella `professioni` (nome provvisorio, non è scritto nel codice), indirizzo `https://fdelse.github.io/professioni/`. **La cartella è già su GitHub** (caricata il 24 ottobre 2026).

## 2. Struttura dei file

```
professioni/
├── index.html      versione 2.2   solo la struttura della pagina
├── app.js          versione 2.2   codice: carica i dati, costruisce le schede, ricerca, menu, pulsanti Copia e Stampa
├── style.css       versione 1.2   stile (identico a style.css 1.6 del vademecum di grammatica, cambia solo l'intestazione)
├── favicon.png                    icona propria (medico con stetoscopio), caricata da Fabio il 24 ottobre 2026: NON sostituirla con quella del vademecum di grammatica
└── dati/                          cartella tutta in minuscolo
    ├── medicina.json   versione 1.4   Medicina (14 schede)
    ├── diritto.json    versione 1.1   Diritto (14 schede)
    ├── banca.json      versione 1.1   Banca (14 schede)
    ├── vendite.json    versione 1.1   Vendite (14 schede)
    └── colloqui.json   versione 1.1   Colloqui (1 scheda)
```

Ogni file JSON ha questa forma: `{"versione": "1.3", "livello": "Medicina", "schede": [ … ]}`, con rientro di 2 spazi. Nel campo `lvl` di ogni scheda va l'identificativo del settore: `medicina`, `diritto`, `banca`, `vendite`.

La consegna si fa con uno **zip dell'intera cartella `professioni/`**, da estrarre dentro `fdelse.github.io/`: così ogni file finisce al suo posto (vedi §10). Prima di preparare lo zip, prendere la `favicon.png` da GitHub o dallo zip più recente.

## 3. Regole per le versioni

Le stesse del vademecum di grammatica. Ogni modifica, anche minima, aggiorna il numero di versione dei file toccati.

- **Si modifica un file di dati** (es. `diritto.json`): si aumenta il campo `"versione"` nel JSON. In `app.js` si aggiorna lo stesso numero nell'elenco `DATI` (oggi `{medicina:"1.4", diritto:"1.1", banca:"1.1", vendite:"1.1", colloqui:"1.1"}`) e si aumenta `VERSIONE` e il commento in cima. In `index.html` si aggiornano `app.js?v=…` e il commento in cima.
- **Si modifica `style.css`**: si aumenta il commento in cima. In `index.html` si aggiornano `style.css?v=…` e il commento in cima.
- **Si modifica `app.js`**: si aumentano `VERSIONE` e il commento. In `index.html` si aggiornano `app.js?v=…` e il commento.

## 4. Differenze dal vademecum di grammatica

Tutte in `app.js` e `index.html`:

- **Settori al posto dei livelli.** L'elenco `LEVELS` (il nome è rimasto quello, per tenere il codice uguale) contiene i settori, ognuno con un colore: Medicina `--c-c1`, Diritto `--c-b2`, Banca `--c-a`, Vendite `--c-a2` (aggiunto il 28 ottobre 2026), Colloqui `--c-b1` (aggiunto il 30 ottobre 2026; era il colore di Software). Non restano colori liberi in `style.css`: per un'altra sezione andrebbe aggiunto un colore. Il nome mostrato sotto «Medicina» è **«Medici»**, sotto «Vendite» è **«Venditori e commerciali»**, sotto «Colloqui» è **«Per tutti i settori»**.
- **I settori senza schede non compaiono**: né nel menu, né nella legenda, né nella pagina.
- **Titoli delle sezioni della scheda**: «Lessico» al posto di «Formazione» e «Frasi utili» al posto di «Quando si usa». Restano «Attenzione», «Errori tipici», «Esercizi».
- **La ricerca legge anche le tabelle** (titoli, testi prima e dopo, intestazioni, righe), perché qui le tabelle contengono il lessico. Restano fuori, come nell'altro vademecum, errori tipici ed esercizi.
- **Testi della pagina**: titolo «Vademecum dell'italiano per le professioni», nel menu «Vademecum delle professioni», campo di ricerca «Cerca un termine…».
- L'etichetta delle soluzioni è **«Soluzioni»**, senza «(docente)»: tolta il 24 ottobre 2026 in tutti e due i vademecum.
- **Pulsanti «Stampa» e «Stampa esercizi»** (dal 29 ottobre 2026, `app.js` 1.9 e `style.css` 1.2, come nel vademecum di grammatica): stampano lo stesso contenuto della copia, su un foglio A4 pulito in bianco e nero; niente soluzioni e, nei role play, niente «Difficoltà da introdurre». Dalla finestra di stampa si può salvare in PDF. Provato in Chromium su tutte le 56 schede; il 30 ottobre 2026 Fabio ha provato la stampa: funziona. Non provato su carta né in Safari e Firefox.
- **Pulsanti «Copia»** (dal 28 ottobre 2026, `app.js` 1.8 e `style.css` 1.1, lo stesso sistema del vademecum di grammatica): «Copia» in alto a destra di ogni scheda copia la spiegazione (definizione, lessico, tabelle, frasi utili, esempi, avviso, errori tipici); «Copia esercizi», dentro la sezione Esercizi, copia i quattro gruppi senza soluzioni. Ogni copia contiene due formati: HTML per Google Docs, Word ed email; testo semplice per WhatsApp e la chat di Preply. Differenze da quello di grammatica: nel copiato le sezioni si chiamano «Lessico» e «Frasi utili»; nei **role play** la frase finale della consegna «Difficoltà da introdurre: …» **non si copia** (deciso da Fabio il 28/10: è la sorpresa del docente), quindi allo studente arrivano ruoli, situazione e i 6 obiettivi. La regola funziona solo se la frase comincia esattamente con «Difficoltà da introdurre:» e sta in fondo alla consegna, com'è in tutti i 56 role play: nelle schede nuove va scritta così. Provato in Chromium su tutte le 56 schede; il 30 ottobre 2026 Fabio ha provato l'incolla in Docs, Word, WhatsApp e Preply: funziona.

## 5. Schema di una scheda

I campi sono gli stessi del vademecum di grammatica, nello stesso ordine: `lvl`, `cat`, `title`, `def`, `form`, `tables`, `uses`, `warn`, `errors`, `exercises`. Come si usano qui:

| campo | contenuto | come appare |
|---|---|---|
| `cat` | categoria dentro il settore (Medicina: Anatomia, Visita, Esami, Terapia, Strutture, Documenti, Prevenzione, Comunicazione; Vendite: Presentazione, Contatto, Trattativa, Offerta e ordine, Dopo la vendita, Negozio, Eventi, Numeri; Banca: Conto, Pagamenti, Credito, Risparmio, Sportello, Digitale, Economia, Fisco, Clienti, Organismi) | etichetta sopra il titolo |
| `def` | a che cosa serve la scheda, in quale situazione | paragrafo iniziale |
| `form` | il quadro della situazione: chi parla con chi, formule fisse, registro, dati istituzionali. **Niente spiegazioni grammaticali** | testo della sezione «Lessico» |
| `tables` | il lessico: di solito parola comune / termine tecnico / a che cosa serve; falsi amici (vedi §6); sigle | tabelle nella sezione «Lessico» |
| `uses` | `[{label, ex}]`: frasi pronte per la situazione, con il termine chiave in `<b>`, separate da ` / `; le etichette non nominano regole grammaticali | sezione «Frasi utili» |
| `warn` | insidie: falsi amici, registro, sigle con due significati | riquadro «Attenzione» |
| `errors` | `[{wrong, right, why}]`, 5–7 per scheda, **solo errori di lessico e d'uso** (falsi amici, calchi, soprattutto dall'inglese: vedi §6); niente errori di grammatica, di ortografia o di comunicazione | sezione «Errori tipici» |
| `exercises` | **4 gruppi da 6**, con le soluzioni (vedi sotto) | sezione «Esercizi» richiudibile |

Esercizi, sempre in questo ordine, con il livello nel campo `type` (es. `"Completamento (A2–B1)"`):

1. **A2–B1** — di solito Completamento con un elenco di parole del lessico della scheda
2. **B1–B2** — Riformulazione, Classificazione, Calcolo, Domande o simili
3. **B2–C1** — Produzione guidata: spiegare, rispondere a una domanda o a una reazione
4. **Role play (tutti i livelli)** — `instr`: ruoli (lo studente è il professionista, il docente fa l'altra parte), situazione e, in fondo, una **difficoltà da introdurre** che comincia sempre con «Difficoltà da introdurre:» (il pulsante «Copia esercizi» la toglie: vedi §4); `items`: 6 obiettivi; `key`: una frase d'esempio per obiettivo, con «Esempio:»

Le tabelle usano sempre `before` (titoletto in grassetto) e `plain: true`; `after` per una nota sotto la tabella. La tabella dei falsi amici ha il titoletto «Falsi amici.» e di solito le colonne `italiano | inglese (e altre lingue) | attenzione`.

## 6. Regole per il contenuto (decise e applicate)

- Una scheda per argomento o situazione di lavoro, con la parola di tutti i giorni accanto a quella tecnica, frasi pronte, insidie, errori ed esercizi.
- Linguaggio chiaro; i termini tecnici del settore si spiegano sempre con parole semplici.
- **Falsi amici e calchi soprattutto con l'inglese** (regola del 28 ottobre 2026, perché gli studenti sono internazionali). Lo spagnolo (o un'altra lingua) entra solo per i casi più forti e frequenti, indicando la lingua («sp.»): **al massimo un errore tipico solo spagnolo per scheda**; nelle tabelle possono restare le note spagnole più utili. Se per una scheda non si trova un calco inglese sicuro, si lascia un secondo spagnolo invece di inventare un errore. Verificare che la parola straniera citata esista davvero con quel significato.
- **Errori tipici: solo errori veri.** Una forma corretta, anche se solo del parlato, meno curata, letteraria, antiquata o del gergo professionale, non va presentata come errore. Casi già incontrati, da NON usare come errori: *ho male alla testa*, *ha diritto a rifiutare*, *capisco che è difficile*, *anestesia totale*, *fare riposo*, *costipato* per «raffreddato» (Medicina, 25/10); *realizzare* per «rendersi conto», *riparazione* per «risarcimento», *ordinazione* per le merci, *raggiungere* qualcuno al telefono, *processare* un ordine, *schedulare*, *commissione* per il compenso, *convention* per le riunioni aziendali, *maneggiare* denaro, *ingresso libero* (Vendite, 28/10); *medicamento*, *la cintura*, *ammesso* in reparto, *teatro operatorio*, *forma mite*, *avere la temperatura*, *disordine* (Medicina, 28/10); *ritorno* sull'investimento, *compensazione* per un disagio, *cane da guardia* per la Consob, *numero di sicurezza sociale*, *notificazione*, *eleggibile* (nei bandi), *guadagno in conto capitale*, *rendita fissa*, *assicurare* per «mettere al sicuro», *redimere* i punti o i buoni (anglicismo in espansione), *collateral* nel gergo bancario (Banca, 28/10); *statuto* (è anche il nome di leggi: Statuto dei lavoratori), *giuria* (usato, impropriamente, per la corte d'assise), *derogare* (anche «abrogare in parte»), *provvedere che*, *regolazione* come «disciplina», *praticare* la professione legale, *firma* per «ditta», *fiscale* (antico nome del pubblico ministero), *convegno* («patto», antico), *assegnazione* (ha anche sensi di trasferimento), *rassegnazione* delle dimissioni, *chiusura* («conclusione»), *parenti* per «genitori» (letterario), *autorità parentale* (termine ufficiale del codice civile svizzero), *tramite* come sostantivo («via»), *attuale* nel senso filosofico, *consiglio* per «consigliere», *scrittura pubblica* e *intervista d'assunzione* (tutti e tre nel De Mauro), *carta* per «documento»; *legge governante* tolto per prudenza (Diritto, 28/10). Attenzione: *barra* è anche il posto degli avvocati in tribunale (l'errore *iscritto alla barra* resta, con questa nota). Nel dubbio, si sceglie un calco sicuro che non dipende da un dizionario.
- **Esercizi**: niente item con due risposte giuste e una sola chiave; quando le risposte possibili sono più di una, la chiave comincia con «Esempio:». Ricontrollare i conti negli esercizi con numeri.
- **Indicazioni pratiche** (cliniche, legali, fiscali, finanziarie) negli esempi: prudenti e aggiornate; per le cose che cambiano da un caso all'altro si rimanda al foglio, al contratto, all'amministrazione o alle regole attuali. Niente date reali di eventi non verificate (es. date di una fiera).
- **Ripetizioni tra settori permesse** (deciso da Fabio il 28 ottobre 2026, durante Diritto): ogni studente segue un solo settore, quindi termini e concetti si possono ripetere, e anche spiegare, in più settori. I doppioni si evitano solo **dentro** lo stesso settore. La regola qui sotto e la sua tabella sono quelle con cui sono stati fatti Vendite e Banca.
- **Sovrapposizioni tra settori** (regola del 25 ottobre 2026, superata il 28/10 dalla regola precedente): ogni argomento ha **un solo settore che lo spiega**; gli altri lo trattano solo dal punto di vista del loro professionista, con un rimando breve nel testo («i pagamenti sono spiegati in Banca»). Casi già decisi:

  | argomento | lo spiega | negli altri settori |
  |---|---|---|
  | pagamenti, Ri.Ba., bonifico | Banca | Vendite: solo come condizione di pagamento nell'offerta |
  | contratto, clausole, inadempimento, caparra, risarcimento | Diritto | Vendite: l'ordine, la conferma e la trattativa |
  | contratto di lavoro, licenziamento | Diritto | Software: niente |
  | privacy e GDPR | nessun settore: doveva essere Software, che non si fa | Diritto e Vendite: niente (deciso da Fabio il 28/10: in Vendite nessun cenno, neanche un rimando) |
  | reclami | Vendite (cliente → azienda) e Banca (cliente → banca) | situazioni diverse |
  | bilancio, utile, ricavi | Banca | Vendite: solo i numeri del commerciale (fatturato, margine, obiettivi, provvigioni) |
  | preventivo | Vendite | Software: solo stime, requisiti e perimetro |
  | partita IVA | Banca (*Il credito alle imprese*) | Vendite: solo citata come dato per la fattura |
  | codice fiscale | Banca (*Il cliente straniero*) | Vendite e *Il fisco del cliente*: solo citato |
  | Ri.Ba., anticipo fatture | Banca (*Il credito alle imprese*) | *Pagamenti*: solo rimando |
  | ABF, ACF (procedura) | Banca (*Email ai clienti e reclami*) | *Sigle e organismi*: solo sigla e ruolo |
  | identificazione, antiriciclaggio | Banca (*Allo sportello*) | *Il cliente straniero*: solo quello che cambia per lo straniero |
  | mutuo, ipoteca, perizia | Banca (*Prestiti e mutui*) | Diritto (*La compravendita immobiliare*): preliminare, rogito, notaio, con rimando |
  | imposta di bollo, tasse sui prodotti | Banca (*Il fisco del cliente*) | *Il conto corrente*: solo citata; il 730 e le detrazioni in generale: niente (CAF, commercialista) |
  | assicurazioni | nessun settore (tolte da Banca il 28/10: non sono un tema bancario) | — |

  Al revisore si chiedono i doppioni dentro il settore, non quelli tra settori (regola del 28/10).
- **Controlli**: i dati istituzionali e normativi (leggi, numeri, sigle ufficiali, regole del settore) si verificano su fonti; ogni settore finito viene riletto da un revisore separato prima della consegna, e le sostituzioni fatte dopo la revisione si fanno ricontrollare con una revisione mirata. Va sempre detto a Fabio che nessun esperto del settore ha rivisto le schede.

## 7. Indice

Approvato da Fabio il 24 ottobre 2026, allargato il 25 ottobre 2026 a **14 schede per settore**, con il settore Vendite. Fatti: Medicina, Vendite, Banca e Diritto, più la sezione Colloqui (1 scheda, 30/10). Software non si fa (deciso da Fabio il 28 ottobre 2026). I rimandi di Banca e Vendite a Diritto (compravendita, organi e forme delle società, caparra, clausole, ordine con condizioni diverse dall'offerta) puntano a schede che ora esistono.

- **Medicina (fatta, 14):** Il corpo umano; Sintomi: come li descrive il paziente; L'anamnesi; L'esame obiettivo e le istruzioni al paziente; Esami strumentali: prescrivere, preparare, spiegare; Diagnosi e terapia; Farmaci, posologia e ricetta; Chirurgia: l'intervento, l'anestesia, il decorso; In ospedale: reparti, ricovero, dimissione; Referti, sigle e abbreviazioni; Certificati e documenti del medico; Prevenzione e stili di vita; Comunicare con il paziente: consenso informato e cattive notizie; Parlare con i colleghi: presentare un caso, passare le consegne
- **Vendite (fatta, 14):** Presentare l'azienda e il prodotto; Il primo contatto: telefonata, email, LinkedIn; Capire le esigenze del cliente: domande e ascolto; La presentazione commerciale e la dimostrazione; Gestire le obiezioni: prezzo, tempi, concorrenza; La trattativa: sconti, condizioni, concessioni; L'offerta e il preventivo; Chiudere la vendita: l'ordine e la conferma (titolo deciso da Fabio il 28/10 al posto di «l'ordine e il contratto»); Consegna e fatturazione: DDT, fattura elettronica, pagamenti; Il post-vendita: assistenza, garanzia, resi, reclami (solo tra aziende); La vendita in negozio: accoglienza, prova, cassa, cambio e reso (consumatore); Fiere ed eventi; Il follow-up: email e messaggi commerciali; I numeri delle vendite: fatturato, margine, obiettivi, provvigioni
- **Diritto (fatta, 14):** Le fonti del diritto: Costituzione, codici, leggi e decreti; Organi giudiziari e professioni legali; Il processo civile: citazione, udienza, sentenza, esecuzione; Il processo penale: denuncia o querela, indagato o imputato; Il contratto: gli elementi essenziali; La struttura di un contratto: premesse, articoli, firme; Le clausole tipiche: recesso, penale, caparra, foro, forza maggiore; Inadempimento, risoluzione e risarcimento del danno; Il contratto di lavoro: assunzione, CCNL, licenziamento, TFR; Le società: srl e spa, atto costitutivo, organi sociali; La compravendita immobiliare: proposta, preliminare, rogito; Famiglia e successioni; Formule e latinismi del linguaggio giuridico; Le lettere legali: diffida, messa in mora, PEC
- **Banca (fatta, 14):** Il conto corrente; Il cliente straniero in banca: codice fiscale, conto per non residenti, documenti; Pagamenti: bonifico, addebito diretto, carte, F24, pagoPA; Prestiti e mutui: TAN, TAEG, ammortamento, ipoteca, fideiussione; Il credito alle imprese: fido, anticipo fatture, Ri.Ba.; Investimenti: azioni, obbligazioni, titoli di Stato, fondi, profilo di rischio; Il risparmio e i depositi: conto deposito, libretto, buoni postali, garanzia dei depositi (al posto di *Le assicurazioni*, deciso da Fabio il 28/10); Allo sportello: identificazione e antiriciclaggio; Banca digitale e sicurezza: home banking, SCA, OTP, truffe; Il linguaggio del bilancio; Le notizie finanziarie: Borsa, spread, rating, rialzo e ribasso; Il fisco del cliente: bollo, tasse sui rendimenti, interessi del mutuo (ristretta alle tasse sui prodotti bancari, deciso da Fabio il 28/10); Email ai clienti e reclami; Sigle e organismi: BCE, Banca d'Italia, Consob, ABF, Centrale dei Rischi
- **Software (non fatto per decisione di Fabio; indice previsto, se un giorno si riprende):** I verbi presi dall'inglese (committare, pushare, deployare); Il genere dei termini inglesi (il branch, la pull request, l'API); Riunioni agile e sprint; Lavorare da remoto (chat, videochiamate, comunicazione asincrona); Code review: proporre modifiche con cortesia; Descrivere un bug e scrivere un ticket; Test e collaudo (test unitari, regressione, staging); Rilasci e incidenti in produzione (rollback, postmortem, comunicare un disservizio); Documentazione e README; Parlare con il cliente (requisiti, preventivo, cambi di perimetro); Stime, scadenze e ritardi; Lessico di architettura e sicurezza; Privacy e GDPR per sviluppatori; Il colloquio tecnico

Nota (solo se si riprende Software): con la regola «niente grammatica» alcune schede (*Il genere dei termini inglesi*, *Documentazione e README: infinito o imperativo*) andranno impostate come lessico e uso, non come regole; da decidere con Fabio quando si arriva lì. In *Parlare con il cliente* il preventivo si cita con un rimando a Vendite.

## 8. Stato attuale

### Medicina (versione 1.4)

Completa dal 25 ottobre 2026: 14 schede, ognuna con 2–4 tabelle, 4–6 frasi utili, un riquadro «Attenzione», 5–6 errori tipici, 3 gruppi di esercizi per livello e un role play.

Lavoro del 25 ottobre 2026: 5 schede nuove, le 9 originali adeguate (tolte le spiegazioni grammaticali, errori di grammatica sostituiti con errori di lessico, esercizi riordinati per livello, role play in ogni scheda); settore rinominato «Medici».

Lavoro del 28 ottobre 2026 (versione 1.3): applicata la regola sui falsi amici (§6). Circa 50 errori tipici solo spagnoli sostituiti con calchi inglesi (es. *droga*, *medicazioni*, *tavoletta*, *effetti laterali*, *sopra il banco*, *si è ricoverato bene*, *La scarichiamo*, *in ICU*, *fuori malato*, *nota di malattia*, *impiegatore*, *additivo*, *passato via*, *simpatico*, *referenza*, *in chiamata*); ora un solo errore solo spagnolo per scheda. Tabelle «Falsi amici» aggiornate (Corpo umano, Sintomi, Esami, Chirurgia, Certificati, Prevenzione, Colleghi). Tolti due errori che erano italiano corretto (*medicamento*, *la cintura*). Revisione separata (2 alte, 12 medie, 15 basse, applicate) e revisione mirata delle sostituzioni (10 su 14 approvate senza riserve, le altre 4 corrette).

Dati verificati su fonti (24–25/10, invariati):

- **Codici di triage** (24/10): dalle linee guida nazionali del 2019, cinque codici numerici al posto dei quattro colori: 1 rosso emergenza, 2 arancione urgenza, 3 azzurro urgenza differibile, 4 verde urgenza minore, 5 bianco non urgenza; le regioni li hanno adottati in tempi diversi.
- **112** (24/10): numero unico di emergenza attivo in gran parte d'Italia; il 118 resta il numero delle emergenze sanitarie.
- **116117** (24/10): numero della guardia medica (continuità assistenziale) in molte regioni.
- **Ricetta** (24/10): quasi sempre elettronica; promemoria o numero (NRE); in farmacia serve la tessera sanitaria.
- **Consenso informato** (24/10): legge 22 dicembre 2017, n. 219; DAT e fiduciario.
- **Classi di priorità della ricetta** (25/10): U entro 72 ore, B entro 10 giorni, D entro 30 giorni (visite) o 60 (esami), P entro 120 giorni (Regione FVG).
- **TC con mezzo di contrasto** (25/10): digiuno da almeno 6 ore, creatinina, segnalare allergie e farmaci per il diabete (informativa AReSS Puglia).
- **Fasce di reperibilità** (25/10): 10–12 e 17–19 tutti i giorni, uguali per pubblici e privati (messaggio INPS 4640/2023).
- **Certificato di malattia** (25/10): telematico, il datore di lavoro vede solo la prognosi.
- **Certificato sportivo** (25/10): non agonistico dal medico di famiglia o pediatra, con ECG a riposo; agonistico solo dal medico dello sport; validità un anno; per la palestra privata non è obbligatorio per legge.
- **Screening oncologici** (25/10): mammografia 50–69 anni ogni 2 anni (in alcune regioni 45–74); Pap test dai 25 anni ogni 3 anni, HPV test da 30–35 a 64 anni ogni 5 anni; sangue occulto fecale 50–69 anni ogni 2 anni.
- **Vaccini dell'adulto** (25/10): antinfluenzale gratuito dai 60 anni (Regione Toscana); anti-pneumococco e anti-zoster dai 65; richiamo dTpa ogni 10 anni (PNPV 2023–2025).
- **Alcol** (25/10): unità alcolica 12 g; basso rischio fino a 2 UA al giorno per gli uomini, 1 per donne e over 65 (ISS).

Lavoro del 30 ottobre 2026 (versione 1.4), approvato da Fabio:

- **9 errori tipici** che erano di grammatica, forma o comunicazione (non 8, come diceva la ripartenza) sostituiti con calchi inglesi: *Sprema le mie dita* → *Mi stringa forte le dita*; *È tenero qui?* → *Le fa male se premo qui?*; *Attacchi fuori la lingua* → *Tiri fuori la lingua* (Esame obiettivo); *espirato* → *scaduto* (Farmaci); *una goccia nel braccio* → *una flebo* (Chirurgia); *venuto indietro positivo* → *risultato positivo*, *cultura delle urine* → *urinocoltura* (Referti); *Suo padre è confortevole* → *sta comodo e non soffre* (Comunicare); *l'abbiamo iniziato su antibiotici* → *abbiamo iniziato una terapia antibiotica* (Colleghi). Revisione separata e poi revisione mirata delle correzioni: applicate tutte (frasi corrette più naturali, *esempio di urine* sostituito perché il legame con *sample* era debole, *confortevole* messo in bocca al medico). Il revisore non ha potuto aprire dizionari: giudizi sulla competenza linguistica.
- **Maiuscole di cortesia**: 76 forme rivolte al paziente, al familiare o al collega a cui si dà del Lei portate a *Le, La, Lei, Suo, Sua, Suoi, Sue*. Restano minuscole le forme di terza persona (*sulla sua paura*, *di sua volontà*, *la dimettiamo* detto della madre) e quelle tra colleghi che si danno del tu (*la visiterai*, *le aumento l'ossigeno*). Le forme con l'apostrofo (*l'aspetto*) non sono state toccate.
- **Doppioni tolti**: *medico di guardia* resta in *Parlare con i colleghi*; *day surgery* in *Chirurgia*; *cartella clinica* in *In ospedale*; il doppio significato di TC in *Referti, sigle e abbreviazioni*; positivo e negativo in *Referti* (riquadro «Attenzione», che ora spiega tutti e due). Nelle altre schede la riga della tabella o la frase dell'avviso diventa «vedi *Titolo*».
- Controllo: pagina caricata in Chromium con 57 schede e nessun errore.

### Vendite (versione 1.1)

Completo dal 28 ottobre 2026: 14 schede, ognuna con 3–4 tabelle (sempre una di falsi amici), 6 frasi utili, un riquadro «Attenzione», 5–6 errori tipici, 4 gruppi di esercizi da 6 (anche un esercizio di calcolo nei Numeri). Scheda di prova approvata: *L'offerta e il preventivo*. Lavorato a blocchi; nei role play lo studente è il venditore.

Dati verificati su fonti (28/10):

- **Aliquote IVA**: 22% ordinaria; 10%, 5%, 4% ridotte (Fiscozen, aggiornato giugno 2026); l'aliquota la stabilisce la legge.
- **Incoterms 2020** in vigore; l'ICC ha appena avviato i lavori per gli Incoterms 2030, senza data (DHL); undici sigle.
- **Porto franco / porto assegnato**: trasporto pagato da chi spedisce / da chi riceve (Money.it).
- **30 gg d.f.f.m.**: di solito si paga l'ultimo giorno del mese dopo quello della fattura; nel dubbio vale il contratto (Studio Madera).
- **Fattura elettronica**: immediata allo SdI entro 12 giorni dall'operazione; differita (con i DDT) entro il 15 del mese successivo (Fiscozen; art. 21 DPR 633/72); codice destinatario di 7 caratteri, 6 per la pubblica amministrazione; il PDF per email è solo una copia di cortesia.
- **DDT**: non obbligatorio in ogni caso (DPR 472/1996), ma quasi sempre presente; serve per la fattura differita.
- **Garanzia legale** (consumatori): 2 anni dalla consegna per i beni nuovi; se il difetto compare entro un anno si presume che c'era già; il consumatore si rivolge al venditore; rimedi: riparazione o sostituzione, poi riduzione del prezzo o risoluzione del contratto (MIMIT). Dal 2022 non c'è più il termine di due mesi per denunciare il difetto (CMS).
- **Diritto di recesso**: 14 giorni per gli acquisti a distanza e fuori dai locali commerciali, con eccezioni; nel negozio fisico non c'è per legge, ma se il negozio promette cambio o reso deve rispettarlo (Altroconsumo).
- **Scontrino**: il nome ufficiale è *documento commerciale*.
- **Made in Italy**: conta l'ultima trasformazione sostanziale; nella scheda si rimanda all'ufficio legale.
- **Comodato**: prestito gratuito di un bene (art. 1803 c.c.).

Revisioni: revisione separata del 28/10 su tutto il settore (38 osservazioni: 2 alte, 17 medie, 19 basse), applicate tutte tranne due proposte del revisore (*processare*, *schedulare*: gergo aziendale, non errori). Poi ridotto a un errore solo spagnolo per scheda con 13 calchi inglesi nuovi (*Le ritorno la chiamata*, *rumori*, *infatti*, *libera*, *contrattato*, *eccitati*, *parcella*, *collezionare*, *fuori ordine*, *maneggiare*, *ricetta*, *cambio*, *convenzione*). Revisione mirata di questi 13 (28/10): 6 approvati senza riserve; *infatti* sostituito con un esempio più netto (→ *invece*); spiegazioni precisate per *maneggiare*, *libero*, *rumore*, *contrattare*; *convenzione* tenuto, con la nota che *convention* è corretto; frase di *collezionare* cambiata perché dava la soluzione di un esercizio. Tre schede avevano ancora due errori solo spagnoli: sostituiti *tienda*, *tarjeta*, *mensual* con *magazine* → magazzino, *advertise* → avvertire, *gross* → grosso (versione 1.1). Ora ogni scheda ha un solo errore solo spagnolo (in *Chiudere la vendita* il secondo, *contrattare*, è attribuito anche all'inglese).

**Non riletti da un revisore separato**: gli 11 calchi inglesi messi dopo la prima revisione (*corporazione*, *Sinceramente*, *elaborare*, *audienza*, *indirizzare*, *rata*, *abusivo*, *fissare*, *esibizione*, *mi lasci sapere*, *quarto*; alcuni li aveva proposti il revisore stesso) e i 3 nuovi (*magazine*, *advertise*, *gross*).

**Non verificato**: nessun commerciale, commercialista o avvocato ha riletto le schede. Le regole della garanzia tra aziende sono solo citate (contratto e codice civile), non spiegate. Il revisore non ha potuto consultare Treccani e Zingarelli: i falsi amici sono controllati su altre fonti e sulla conoscenza della lingua.

### Banca (versione 1.1)

Completo dal 28 ottobre 2026: 14 schede, ognuna con 3 tabelle (sempre una di falsi amici), 6 frasi utili, un riquadro «Attenzione», 5 errori tipici, 4 gruppi di esercizi da 6 (con esercizi di calcolo in *Il risparmio e i depositi* e *Il fisco del cliente*). Scritte senza domande intermedie, su richiesta di Fabio («fai tutto senza domande poi fai rivedere»). Decisioni di Fabio prima della scrittura: confini del §6; *Le assicurazioni* sostituita da *Il risparmio e i depositi*; solo temi strettamente bancari, al massimo di economia. Nei role play lo studente è il bancario. Ogni scheda ha al massimo un errore tipico solo spagnolo (*Banca digitale* e *Prestiti e mutui* nessuno).

Dati verificati su fonti (28/10):

- **TAN e TAEG**: il TAEG comprende interessi e spese obbligatorie (Altroconsumo).
- **Surroga** gratuita (legge 40/2007); estinzione anticipata senza penali per i mutui casa delle persone fisiche (Studio Cataldi).
- **Bonifico istantaneo**: obbligatorio per le banche, stesso costo dell'ordinario dal 9 gennaio 2025, verifica del beneficiario dal 9 ottobre 2025, fino a 10 secondi, irrevocabile (Reg. UE 2024/886; LeggiOggi). Lo stesso costo vale per le banche dell'area euro.
- **IBAN** italiano di 27 caratteri (Money.it).
- **Limite al contante** 5.000 euro anche nel 2026: vietati i pagamenti pari o superiori (BusinessOnline).
- **Imposta di bollo**: 34,20 euro sul conto delle persone fisiche con giacenza media sopra i 5.000 euro; 0,2% su dossier titoli e conti deposito (Intesa Sanpaolo, Money.it).
- **Ritenute**: 26% su interessi di depositi e rendimenti; 12,5% su titoli di Stato e buoni postali (QuiFinanza).
- **Detrazione** interessi del mutuo dell'abitazione principale: 19% su massimo 4.000 euro di interessi l'anno; con mutuo cointestato il limite si divide (Money.it, Altroconsumo).
- **FITD**: 100.000 euro per depositante e per banca; copre conti, depositi, libretti, certificati; non azioni, obbligazioni, fondi; rimborso entro 7 giorni; per le BCC c'è il FGD (QualeBanca).
- **Reclami**: risposta entro 60 giorni, 15 giornate lavorative per i servizi di pagamento (35 in casi eccezionali); ABF entro 12 mesi dal reclamo, 20 euro, fino a 200.000 euro (Altroconsumo).
- **Centrale dei Rischi**: segnalazione da 30.000 euro, da 250 euro in sofferenza, accesso gratuito ai propri dati (Banca d'Italia).
- **Conto di base**: gratuito con ISEE inferiore a 11.600 euro, senza canone per pensionati fino a 18.000 euro lordi; diritto per ogni consumatore che soggiorna legalmente nell'UE (Money.it; TUB art. 126-noviesdecies, citato dal revisore).
- **Codice fiscale** per stranieri: Agenzia delle Entrate; dall'estero il consolato; per molti lavoratori extra UE lo Sportello unico per l'immigrazione, prima provvisorio (InfoImmigrazione, guida AdE su PartitaIVA.it).
- **Disconoscimento** di operazioni non autorizzate: rimborso entro la giornata operativa successiva salvo sospetto di frode; al massimo 50 euro a carico del cliente salvo dolo o colpa grave; entro 13 mesi (citato dal revisore, guida di una banca).

Revisioni: revisione separata del 28/10 su tutto il settore (4 alte, 29 medie, 24 basse), applicate tutte; i 4 problemi alti erano tre errori tipici che sono italiano corretto (*ritorno*, *compensazione*, *cane da guardia*) e un role play di Sportello con un versamento che violava il limite al contante. Poi revisione mirata delle 18 sostituzioni (9 approvate senza riserve, le altre corrette). Due calchi messi dopo la revisione mirata non sono stati riletti: *codice delle tasse* (Il cliente straniero) e *in attaccamento* (Email ai clienti e reclami).

**Non verificato**: nessun bancario, commercialista o avvocato ha riletto le schede. Non controllati online: percentuale finanziata «spesso fino all'80%», polizza scoppio-incendio, chiusura del conto senza penali e trasferimento gratuito, minusvalenze compensabili entro 4 anni, buoni postali emessi da CDP e garantiti dallo Stato, clausola non trasferibile dai 1.000 euro (dalla conoscenza della norma). Treccani e Zingarelli non erano raggiungibili per i revisori. I rimandi a Diritto ora puntano a schede scritte.

### Diritto (versione 1.1)

Completo dal 28 ottobre 2026: 14 schede, ognuna con 3 tabelle (sempre una di falsi amici), 6 frasi utili, un riquadro «Attenzione», 5 errori tipici, 4 gruppi di esercizi da 6 (un esercizio di calcolo delle imposte nella *Compravendita immobiliare*, domande con numeri in *Il contratto di lavoro* e *Famiglia e successioni*). Scritte senza domande intermedie, come Banca. Nei role play lo studente è l'avvocato, il praticante, il consulente del lavoro, il legale interno o il collaboratore del notaio. Ogni scheda ha al massimo un errore tipico solo spagnolo (*Fonti*, *Struttura del contratto*, *Clausole*, *Inadempimento*, *Lavoro* e *Famiglia* nessuno). Di proposito **non** sono indicate le soglie di valore del giudice di pace: le nuove competenze sono rinviate al 31 ottobre 2027 (d.l. 100/2026, citato dal revisore).

Dati verificati su fonti (28/10):

- **Riforma Cartabia**: citazione notificata almeno 120 giorni prima della prima udienza (150 se il convenuto è all'estero); comparsa di risposta almeno 70 giorni prima (artt. 163-bis e 166 c.p.c.); materie di mediazione obbligatoria (d.lgs. 28/2010, art. 5) (Dequo, Brocardi).
- **Processo penale**: informazione di garanzia (art. 369 c.p.p., modificato dalla l. 114/2024); la remissione della querela non ha effetto se il querelato la ricusa (art. 155 c.p.) (Brocardi).
- **Pratica forense**: 18 mesi; a certe condizioni (convenzione tra università e ordine) fino a sei durante l'ultimo anno di università (art. 41 l. 247/2012, Brocardi).
- **Tempo determinato 2026**: libero fino a 12 mesi; da 12 a 24 solo con causale (contratti collettivi o, fino al 31 dicembre 2026, individuata dalle parti per esigenze tecniche, organizzative o produttive; sostituzione); oltre i 24 mesi diventa a tempo indeterminato, salvo i contratti collettivi; un contratto unico di 18 mesi richiede la causale fin dall'inizio (d.l. 95/2025, conv. l. 118/2025; InformazioneFiscale, MySolution). **Il termine del 31 dicembre 2026 scade tra due mesi: dal 2027 vanno ricontrollati form, «Attenzione» e una chiave di *Il contratto di lavoro*.**
- **Società**: srl con capitale anche da 1 euro, versato in denaro e per intero (art. 2463 c.c.); spa minimo 50.000 euro; nella sapa gli accomandatari rispondono illimitatamente (art. 2452 c.c.).
- **Compravendita**: preliminare da registrare entro 30 giorni (art. 13 TUR, modificato dal d.l. 73/2022: prima erano 20, e molti siti lo dicono ancora); da un privato imposta di registro 2% prima casa o 9% sul valore catastale, minimo 1.000 euro, più 50 + 50 euro di ipotecaria e catastale; da un'impresa con IVA 4% / 10% / 22% più tre imposte fisse da 200 euro (comunicato dell'Agenzia delle Entrate del 2014, NotaiOnline, InformazioneFiscale). Il calcolo dell'esercizio è stato ricontrollato.
- **Divorzio**: 6 mesi dopo la separazione consensuale, 12 dopo quella giudiziale (l. 898/1970, art. 3).
- **Successioni**: coniuge e figli 4% oltre 1 milione di euro ciascuno; dichiarazione entro 12 mesi; invariati dopo il d.lgs. 139/2024 (NotaiOnline).
- **Donazione**: atto pubblico con due testimoni, salvo i beni mobili di modico valore consegnati (artt. 782–783 c.c.).
- **Avvocati**: art. 48 del Codice deontologico forense (corrispondenza riservata e proposte transattive non si producono in giudizio); art. 65 (niente minacce sproporzionate o vessatorie).
- **PEC**: ha il valore della raccomandata A/R «salvo che la legge disponga diversamente» (art. 48 CAD, destinato a essere abrogato); INI-PEC per imprese e professionisti, INAD per le persone fisiche.

Revisioni: revisione separata del 28/10 su tutto il settore. Problemi principali: 11 errori tipici che erano italiano corretto secondo il Treccani (*provvede che*, *pratico la legge*, *firma legale*, *il fiscale*, *convegno*, *rassegnazione*, *chiusura*, *parenti* per genitori, *autorità parentale*, *tramite*, *attuale*), 1 errore di diritto (la sapa messa tra le società in cui risponde solo la società), formulazioni troppo assolute (mora, diffida ad adempiere, donazione, minacce nella diffida, valore della PEC) e un role play di *Inadempimento* da rifare (i vizi della cosa venduta hanno regole proprie: ora è un ritardo di consegna). Applicate tutte le correzioni; *statuto*, *giuria* e *derogata* erano già stati tolti prima della revisione. Doppioni interni: la diffida ad adempiere è spiegata in *Inadempimento*, *Le lettere legali* ora rimanda a quella scheda; caparra (*Clausole* e *Compravendita*) e prescrizione (*Inadempimento* e *Latinismi*) restano in due schede, da due punti di vista diversi. Poi revisione mirata delle 17 sostituzioni e delle frasi di diritto cambiate: 14 sostituzioni approvate; 3 erano ancora registrate nel De Mauro (*consiglio legale*, *scrittura pubblica*, *intervista di lavoro*) e sono state sostituite con *appuntare* un consulente (to appoint), *elevare a pubblico* (sp. elevar a público) e *applicazione* per «candidatura». **Queste tre le ha controllate solo il revisore che le ha proposte**, su Treccani e De Mauro.

**Non verificato**: nessun avvocato, notaio o consulente del lavoro ha riletto le schede. Zingarelli, Devoto-Oli e il Garzanti completo non erano raggiungibili; Treccani e De Mauro sì. Le pagine dell'Agenzia delle Entrate non si aprivano: le imposte fisse da 50 euro tra privati, le condizioni del prezzo-valore e i requisiti prima casa sono controllati solo su fonti secondarie. Citati senza riaprire il testo: artt. 641 c.p.c. e 124 c.p.; artt. 581, 1350, 1385–1386, 1406, 2120, 2327 c.c.; d.lgs. 231/2002; l. 604/1966; UNILAV; Reg. UE 650/2012; Codice del consumo (recesso di 14 giorni, foro del consumatore). Restano errori con un piccolo rischio secondo il revisore: *data effettiva* (Struttura del contratto) e *diritto di ritiro* (Clausole).

### Colloqui (versione 1.1)

Sezione aggiunta il 30 ottobre 2026 su richiesta di Fabio, con una sola scheda: *Il colloquio di lavoro* (categoria Colloquio), valida per gli studenti di tutti i settori. Decisioni di Fabio: colloquio di lavoro (non l'orale delle certificazioni); una sezione nuova invece di una scheda per settore; il docente fa il selezionatore e legge le domande; vanno incluse le domande a trabocchetto e le domande che il candidato non deve fare; il numero di domande lo decide Claude.

Struttura: nella spiegazione le fasi e i tipi di colloquio, come riconoscere le domande a trabocchetto, tre tabelle (lessico del colloquio, domande del candidato da fare e da evitare, falsi amici), 8 frasi utili, un riquadro su registro, domande vietate e stipendio, 6 errori tipici. Esercizi: **deviazione voluta dalla regola dei 6 per gruppo** — 10 domande per gruppo (*Domande di base* A2–B1, *Esperienza e competenze* B1–B2, *Domande a trabocchetto* B2–C1) e un role play con 8 obiettivi. Nelle soluzioni: una risposta d'esempio (la candidata è sempre Ana Ruiz, economista, impiegata amministrativa) e, per le domande a trabocchetto, che cosa vuole sapere davvero il selezionatore. Con «Copia esercizi» e «Stampa esercizi» lo studente riceve solo le domande.

Dati verificati su fonti (30/10): art. 8 legge 300/1970, divieto di indagini sulle opinioni politiche, religiose o sindacali e su fatti non rilevanti per l'attitudine professionale (Brocardi); art. 27 d.lgs. 198/2006, divieto di discriminazione nell'accesso al lavoro anche con riferimento allo stato matrimoniale o di famiglia e alla gravidanza (Brocardi); **d.lgs. 96/2026** sulla trasparenza retributiva (direttiva UE 2023/970), in vigore dal 7 giugno 2026: retribuzione iniziale o fascia e contratto collettivo applicato **nell'annuncio** (la formula «prima del colloquio» è della direttiva UE, non del decreto: alcuni giornali la riportano per errore); divieto di chiedere, anche tramite agenzie, la retribuzione attuale o precedente (Fanpage, EC News, estratto della Gazzetta Ufficiale pubblicato da dirittobancario.it; testo su Normattiva non consultato); periodo di prova al massimo sei mesi, art. 7 d.lgs. 104/2022 (FiscoeTasse).

Revisioni (30/10): revisione separata della scheda. Correzioni principali: la formula «o prima del colloquio» del d.lgs. 96/2026 era sbagliata (corretto: nell'annuncio, con il contratto collettivo); l'art. 27 del Codice delle pari opportunità vieta di discriminare, non di fare domande (il divieto di domande viene dall'art. 8 dello Statuto); la candidata d'esempio lavora ancora, quindi le domande sul lavoro sono al presente; errore *Ho fatto il mio meglio* sostituito (differenza grammaticale e forma diffusa) con *eventualmente* per «alla fine» (ingl. *eventually*); aggiunti al lessico fascia retributiva, CCNL e livello, mansioni, tempo pieno / part-time; aggiunti i falsi amici *intervista*, *master*, *compagnia*; tolte le ripetizioni interne. Poi revisione mirata delle correzioni: approvate, con piccoli ritocchi (*eccitato* vuol dire soprattutto agitato; «di solito, l'età», perché l'età conta per l'apprendistato; il lavoro a progetto non esiste più dal 2015). Il 30 ottobre 2026 (versione 1.1), su osservazione di Fabio, nella tabella delle domande del candidato le tre etichette «non subito» sono diventate «no, al colloquio» (ferie e ponti), «sì, ma alla fine e con altre parole» (quanto guadagnerei) e «no, in questa forma» (sempre da casa). Come errori tipici non si usano *applicare* (gergo delle risorse umane, sta solo in tabella) e *intervista* (registrata nel De Mauro).

### Per tutti i settori

**Non verificato**: nessun medico, professionista delle vendite, bancario, avvocato, notaio o selezionatore del personale ha riletto le schede. Le indicazioni cliniche negli esempi di Medicina (tempi di ripresa, preparazioni di ecografia, risonanza ed endoscopie, scelte di terapia) sono di buon senso e non sono state controllate su linee guida.

## 9. Come lavorare in una nuova conversazione

- Chiedere a Fabio i file attuali (lo zip della cartella oppure il JSON del settore, `app.js` e `index.html`) e lavorare sempre su quelli, non su copie vecchie. La cartella è su GitHub (repository pubblico): si può confrontare con la copia online.
- Prima di modificare: dire cosa si intende fare e aspettare la conferma. **Una domanda alla volta.** Un settore alla volta; per un settore nuovo si propone prima una scheda di prova, poi si lavora a blocchi di 3–4 schede, mostrando ogni blocco.
- Per le sostituzioni di errori tipici: mostrare prima l'elenco, applicare dopo il sì, poi far ricontrollare.
- Dopo ogni modifica: controllare che la pagina si carichi senza errori, contare le schede, provare la ricerca con alcuni termini delle tabelle.
- Consegnare lo zip della cartella intera, oppure i file con il nome esatto e la cartella in cui vanno (i JSON in `dati/`, gli altri in `professioni/`).

## 10. Problemi già incontrati (anche nel vademecum di grammatica)

- **File nella cartella sbagliata.** Il 19 e il 24 ottobre 2026 `app.js` è finito dentro `dati/`: la pagina mostra solo il titolo, senza menu né schede. `index.html`, `app.js`, `style.css` e `favicon.png` stanno nella cartella principale; in `dati/` solo i file `.json`. Per questo si consegna lo zip.
- **Favicon sovrascritta.** Lo zip del 24 ottobre conteneva ancora la bandiera; la favicon giusta è quella caricata su GitHub. Prenderla sempre da lì. Lo zip del 28 ottobre (pulsanti Copia) non contiene la favicon, così su GitHub resta quella già caricata.
- **Il sito non si aggiorna dopo il commit.** Aspettare qualche minuto e ricaricare con Ctrl+Shift+R; se non cambia nulla, controllare nel repository la scheda **Actions** («pages build and deployment») e githubstatus.com. Il 19 ottobre 2026 un guasto di GitHub Pages ha ritardato la pubblicazione.
- **Maiuscole.** GitHub Pages distingue maiuscole e minuscole: `dati`, non `Dati`.
- **File rinominati.** Scaricando più volte lo stesso file il browser lo chiama `app (1).js`: va caricato con il nome esatto.
- **Prova in locale.** Aperto con un doppio clic, `index.html` non carica i JSON: serve Live Server in VS Code oppure la versione online.
- **Ricerca e sigle brevi.** La ricerca cerca anche dentro le parole: una sigla breve come «RMA» trova anche *conferma* e *farmaci*. Se una scheda ha la parola nel titolo, le altre che la contengono vengono nascoste dietro «mostra anche queste». Non è un errore delle schede.
- **Un file di dati mancante blocca tutto.** `app.js` carica insieme i file di tutti i settori elencati in `LEVELS`: se ne manca uno (errore 404), non compare nessuna scheda e la pagina mostra «Impossibile caricare le schede (dati/….json: 404)». Il 28 ottobre 2026 è successo con `software.json`, che non era su GitHub: risolto togliendo Software da `app.js` (versione 1.7). Se un giorno si aggiunge un settore, il suo file deve esserci, anche vuoto.
